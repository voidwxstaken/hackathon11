import React, { useState, useEffect, useCallback } from 'react';
import { Sparkles, Zap, Rocket, Star } from 'lucide-react';

interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  baseCost: number;
  multiplier: number;
  owned: number;
  icon: React.ReactNode;
}

interface AutoGenerator {
  id: string;
  name: string;
  description: string;
  cost: number;
  baseCost: number;
  production: number;
  owned: number;
  icon: React.ReactNode;
}

function App() {
  const [stardust, setStardust] = useState(0);
  const [clickPower, setClickPower] = useState(1);
  const [totalClicks, setTotalClicks] = useState(0);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number }>>([]);

  const [upgrades, setUpgrades] = useState<Upgrade[]>([
    {
      id: 'click-multiplier',
      name: 'Quantum Fingers',
      description: 'Double your clicking power',
      cost: 15,
      baseCost: 15,
      multiplier: 2,
      owned: 0,
      icon: <Zap className="w-5 h-5" />
    },
    {
      id: 'mega-click',
      name: 'Cosmic Touch',
      description: 'Multiply click power by 5',
      cost: 100,
      baseCost: 100,
      multiplier: 5,
      owned: 0,
      icon: <Sparkles className="w-5 h-5" />
    },
    {
      id: 'ultimate-click',
      name: 'Stellar Burst',
      description: 'Multiply click power by 10',
      cost: 500,
      baseCost: 500,
      multiplier: 10,
      owned: 0,
      icon: <Star className="w-5 h-5" />
    }
  ]);

  const [autoGenerators, setAutoGenerators] = useState<AutoGenerator[]>([
    {
      id: 'stardust-collector',
      name: 'Stardust Collector',
      description: 'Generates 1 stardust per second',
      cost: 50,
      baseCost: 50,
      production: 1,
      owned: 0,
      icon: <Sparkles className="w-5 h-5" />
    },
    {
      id: 'cosmic-harvester',
      name: 'Cosmic Harvester',
      description: 'Generates 5 stardust per second',
      cost: 250,
      baseCost: 250,
      production: 5,
      owned: 0,
      icon: <Rocket className="w-5 h-5" />
    }
  ]);

  // Auto-generation effect
  useEffect(() => {
    const interval = setInterval(() => {
      const totalProduction = autoGenerators.reduce((total, generator) => {
        return total + (generator.production * generator.owned);
      }, 0);
      
      if (totalProduction > 0) {
        setStardust(prev => prev + totalProduction);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [autoGenerators]);

  const createParticle = useCallback((x: number, y: number) => {
    const id = Date.now() + Math.random();
    setParticles(prev => [...prev, { id, x, y }]);
    
    setTimeout(() => {
      setParticles(prev => prev.filter(p => p.id !== id));
    }, 1000);
  }, []);

  const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    setStardust(prev => prev + clickPower);
    setTotalClicks(prev => prev + 1);
    createParticle(x, y);
  };

  const buyUpgrade = (upgradeId: string) => {
    setUpgrades(prev => prev.map(upgrade => {
      if (upgrade.id === upgradeId && stardust >= upgrade.cost) {
        setStardust(current => current - upgrade.cost);
        setClickPower(currentPower => currentPower * upgrade.multiplier);
        
        return {
          ...upgrade,
          owned: upgrade.owned + 1,
          cost: Math.floor(upgrade.baseCost * Math.pow(1.5, upgrade.owned + 1))
        };
      }
      return upgrade;
    }));
  };

  const buyAutoGenerator = (generatorId: string) => {
    setAutoGenerators(prev => prev.map(generator => {
      if (generator.id === generatorId && stardust >= generator.cost) {
        setStardust(current => current - generator.cost);
        
        return {
          ...generator,
          owned: generator.owned + 1,
          cost: Math.floor(generator.baseCost * Math.pow(1.15, generator.owned + 1))
        };
      }
      return generator;
    }));
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return Math.floor(num).toString();
  };

  const totalProduction = autoGenerators.reduce((total, generator) => {
    return total + (generator.production * generator.owned);
  }, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white p-4">
      <div className="container mx-auto max-w-6xl">
        <header className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
            Cosmic Clicker
          </h1>
          <p className="text-purple-300 text-lg">Harvest the power of the cosmos!</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Game Area */}
          <div className="lg:col-span-2 flex flex-col items-center">
            <div className="bg-black/30 backdrop-blur-sm rounded-3xl p-8 mb-6 border border-purple-500/30">
              <div className="text-center mb-6">
                <div className="text-3xl md:text-4xl font-bold text-yellow-400 mb-2">
                  ✨ {formatNumber(stardust)} Stardust
                </div>
                <div className="text-purple-300">
                  {formatNumber(clickPower)} per click • {formatNumber(totalProduction)}/sec
                </div>
              </div>

              {/* Clickable Orb */}
              <div className="relative flex justify-center">
                <div
                  onClick={handleClick}
                  className="relative w-48 h-48 md:w-64 md:h-64 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full cursor-pointer transform transition-all duration-150 hover:scale-105 active:scale-95 shadow-2xl hover:shadow-purple-500/50 flex items-center justify-center"
                  style={{
                    boxShadow: '0 0 50px rgba(168, 85, 247, 0.5), inset 0 0 50px rgba(168, 85, 247, 0.2)'
                  }}
                >
                  <div className="absolute inset-4 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full opacity-60 animate-pulse"></div>
                  <Sparkles className="w-16 h-16 md:w-20 md:h-20 text-white relative z-10" />
                </div>

                {/* Particles */}
                {particles.map(particle => (
                  <div
                    key={particle.id}
                    className="absolute pointer-events-none text-yellow-400 font-bold text-xl animate-bounce"
                    style={{
                      left: particle.x,
                      top: particle.y,
                      animation: 'float-up 1s ease-out forwards'
                    }}
                  >
                    +{formatNumber(clickPower)}
                  </div>
                ))}
              </div>

              <div className="text-center mt-6 text-purple-300">
                Total Clicks: {formatNumber(totalClicks)}
              </div>
            </div>

            {/* Stats */}
            <div className="bg-black/20 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20 w-full max-w-md">
              <h3 className="text-xl font-bold text-center mb-4 text-purple-300">Statistics</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Click Power:</span>
                  <span className="text-yellow-400">{formatNumber(clickPower)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Auto Production:</span>
                  <span className="text-green-400">{formatNumber(totalProduction)}/sec</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Stardust:</span>
                  <span className="text-purple-400">{formatNumber(stardust)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Upgrades Sidebar */}
          <div className="space-y-6">
            {/* Click Upgrades */}
            <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/30">
              <h3 className="text-xl font-bold mb-4 text-center text-purple-300">Click Upgrades</h3>
              <div className="space-y-3">
                {upgrades.map(upgrade => (
                  <button
                    key={upgrade.id}
                    onClick={() => buyUpgrade(upgrade.id)}
                    disabled={stardust < upgrade.cost}
                    className="w-full p-4 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-xl border border-purple-500/30 hover:border-purple-400/50 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-purple-600/30 transition-all duration-200 text-left"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      {upgrade.icon}
                      <div>
                        <div className="font-semibold text-white">{upgrade.name}</div>
                        <div className="text-xs text-purple-300">{upgrade.description}</div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-yellow-400 font-bold">{formatNumber(upgrade.cost)} ✨</span>
                      <span className="text-xs text-gray-400">Owned: {upgrade.owned}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Auto Generators */}
            <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/30">
              <h3 className="text-xl font-bold mb-4 text-center text-purple-300">Auto Generators</h3>
              <div className="space-y-3">
                {autoGenerators.map(generator => (
                  <button
                    key={generator.id}
                    onClick={() => buyAutoGenerator(generator.id)}
                    disabled={stardust < generator.cost}
                    className="w-full p-4 bg-gradient-to-r from-green-600/20 to-blue-600/20 rounded-xl border border-green-500/30 hover:border-green-400/50 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-green-600/30 transition-all duration-200 text-left"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      {generator.icon}
                      <div>
                        <div className="font-semibold text-white">{generator.name}</div>
                        <div className="text-xs text-green-300">{generator.description}</div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-yellow-400 font-bold">{formatNumber(generator.cost)} ✨</span>
                      <span className="text-xs text-gray-400">Owned: {generator.owned}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float-up {
          0% {
            opacity: 1;
            transform: translateY(0px);
          }
          100% {
            opacity: 0;
            transform: translateY(-50px);
          }
        }
      `}</style>
    </div>
  );
}

export default App;